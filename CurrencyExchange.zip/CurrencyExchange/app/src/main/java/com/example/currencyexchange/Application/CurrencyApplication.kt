package com.example.currencyexchange.Application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp
class CurrencyApplication : Application()